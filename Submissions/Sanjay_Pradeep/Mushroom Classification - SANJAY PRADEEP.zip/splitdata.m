function [X]=splitdata(data)
temp=table2array(data(:,1));
    temp=cell2mat(temp);
    temp=grp2idx(temp);
    temp=dummyvar(temp);
    X=temp;
for i=2:22
    temp=table2array(data(:,i));
    temp=cell2mat(temp);
    temp=grp2idx(temp);
    temp=dummyvar(temp);
    X=[X temp];
     
end
end
