%Mushroom classification using Support Vector Machine.
%Load the training set and test set together and label it as 'test'. The model will be trained only using the data in the training set.
%IMPORTANT: The training and test set must be loaded together to run one-hot-encoding of the feature vector without any errors due to matrix dimension mismatch. 

train=readtable('train.csv');
test=readtable('test.csv');
y=table2array(train(:,1));
y=grp2idx(cell2mat(y)); %predictions of training set
train=train(:,2:23);
data=[train; test;];
X=splitdata(data);     % prepare feature vector and implement one-hot-encoding
Xtest=X(7125:8124,:);  % test set
X=X(1:7124,:);         % training set


SVMModel = fitcsvm(X,y,'KernelFunction','linear');
[label,score] = predict(SVMModel,X);
fprintf('Training Accuracy : %f\n', mean(double(label== y)) * 100);


[labeltest,scoretest] = predict(SVMModel,Xtest); 
% fprintf('Test Set Accuracy : %f\n', mean(double(labeltest== ytest)) * 100);

predictions=char(zeros(1000,1));
for i=1:1000
    if(labeltest(i)==1)
        predictions(i)='e';
    elseif(labeltest(i)==2)
        predictions(i)='p';
    end
end