rp = randperm(1000);
for i = 1:1000
    % Display 
    fprintf('\nDisplaying Example Image\n');
    displayData(Xtest(rp(i), :));

    pred = predict(Theta1, Theta2, Xtest(rp(i),:));
    fprintf('\nNeural Network Prediction: %d (digit %d)\n', pred, mod(pred, 10));
    
    % Pause with quit option
    s = input('Paused - press enter to continue, q to exit:','s');
    if s == 'q'
      break
    end
end