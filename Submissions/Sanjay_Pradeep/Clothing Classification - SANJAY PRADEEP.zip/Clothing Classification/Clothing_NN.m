close all; clc

%parameters
input_size  = 784;        % 28x28 Input Images
hidden_layer_units = 30;  % 30 hidden units
num_labels = 10;          % 10 labels, from 1 to 10   
                          % (note that I have mapped "0" to label 10)
     

% Load Training Data
% Copy fashion-mnist_train.csv to working directory! It had to be deleted
% to keep the zip file within permissible limit for upload.

fprintf('Loading and Visualizing Data ...\n')

train=readtable('fashion-mnist_train.csv');
train=table2array(train);
test=readtable('Q2_Clothing_test.csv');
test=table2array(test);

m=60000;
y=train(:,1);
y(y==0)=10;

X=train(:,2:785);
X=X/255;
Xtest=test/255;


% Randomly select 100 data points to display
sel = randperm(size(X, 1));
sel = sel(1:100);

displayData(X(sel, :),28);  %Code taken from Andrew Ng's Coursera course for Machine Learning

fprintf('Program paused. Press enter to continue.\n');
pause;           


fprintf('\nInitializing Neural Network Parameters ...\n')
load('Theta1 and 2.mat'); %load the trained values of Theta1 and Theta2. Replace this with random initialization to train it from the start and set iterations to 200
%Theta1 and Theta2 have been trained for approx 600 iterations(~1.5 hours) now.
initial_Theta1 =Theta1; %randomInitialize(input_size, hidden_layer_units);  
initial_Theta2 =Theta2; %randomInitialize(hidden_layer_units, num_labels);  

% Unroll parameters
initial_nn_params = [initial_Theta1(:) ; initial_Theta2(:)];

fprintf('\n Training Neural Network... \n')
%This part of the code that implements the open-source fmincg optimization
%algorithm is also taken from Andrew Ng's course on Coursera 


options = optimset('MaxIter',10);
lambda = 1;

% Create "short hand" for the cost function to be minimized
costFunction = @(p) nnCostFunction(p, ...
                                   input_size, ...
                                   hidden_layer_units, ...
                                   num_labels, X, y, lambda);

% Now, costFunction is a function that takes in only one argument (the
% neural network parameters)
[nn_params, cost] = fmincg(costFunction, initial_nn_params, options);

% Obtain Theta1 and Theta2 back from nn_params
Theta1 = reshape(nn_params(1:hidden_layer_units * (input_size + 1)), ...
                 hidden_layer_units, (input_size + 1));

Theta2 = reshape(nn_params((1 + (hidden_layer_units * (input_size + 1))):end), ...
                 num_labels, (hidden_layer_units + 1));

fprintf('\nNeural Network Trained! \n')             
fprintf('Program paused. Press enter to continue.\n');
pause;

pred=predict(Theta1, Theta2, X);

fprintf('\nTraining Set Accuracy: %f\n', mean(double(pred == y)) * 100);

predictions=predict(Theta1, Theta2, Xtest);
%displaytest(); Run this to display the images one by one and see the
%prediction of the neural net.