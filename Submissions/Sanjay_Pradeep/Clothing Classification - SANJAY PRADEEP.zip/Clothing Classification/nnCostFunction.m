function [J grad] = nnCostFunction(nn_params, ...
                                   input_layer_size, ...
                                   hidden_layer_size, ...
                                   num_labels, ...
                                   X, y, lambda)

Theta1 = reshape(nn_params(1:hidden_layer_size * (input_layer_size + 1)), ...
                 hidden_layer_size, (input_layer_size + 1));

Theta2 = reshape(nn_params((1 + (hidden_layer_size * (input_layer_size + 1))):end), ...
                 num_labels, (hidden_layer_size + 1));


m = size(X, 1);
         

J = 0;
Theta1_grad = zeros(size(Theta1));
Theta2_grad = zeros(size(Theta2));


%Feed-Forward with two layers
X = [ones(m, 1) X];
a1=X;
z2=X*Theta1';
a2=sigmoid(z2);
a2=[ones(m, 1) a2];
z3=a2*Theta2';
a3=sigmoid(z3);

%We now have the output for the input X stored in a3. Estimate error using
%'y' to get the cost.
tempy=zeros(m,num_labels);
for i=1:m
    % recode y into n dimensional vector form
    tempy(i,:)=zeros(num_labels,1);
    tempy(i,y(i))=1;
end

for i=1:m
    temp=-tempy(i,:)*log(a3(i,:)')-((1-tempy(i,:))*log(1-a3(i,:)'));
        J=J+temp;
end
J=J/m;

% we now need to add the regularization terms
% assume we have theta1 and theta 2 of any size but ignore the first column
% as that corresponds to the bias
theta1s=Theta1.*Theta1;
theta2s=Theta2.*Theta2;
theta1s(:,1)=0;
theta2s(:,1)=0;
regsum=sum(theta1s(:))+sum(theta2s(:));
regsum=regsum*lambda/(2*m);

J=J+regsum;

D2=0;
D1=0;
for i=1:m
    a_1=a1(i,:)';
      %we have our input as a column vector
    z_2=Theta1*a_1;
    a_2=sigmoid(z_2);
    a_2=[1 ;a_2];
    z_3=Theta2*a_2;
    a_3=sigmoid(z_3);
    
    d3=a_3-tempy(i,:)'; %delta in column vector form
    new=Theta2(:,2:end);
    new2=sigmoidGradient(z_2);
    d2=(Theta2(:,2:end)'*d3).*sigmoidGradient(z_2);
    D2=D2+d3*a_2';
    D1=D1+d2*a_1';
end
D2=D2/m;
D1=D1/m;
 Theta1_grad=D1;
 Theta2_grad=D2;
 
 
 
 %Now add regularization to the gradients
 Theta1_grad(:,2:end)=Theta1_grad(:,2:end)+(lambda/m)*Theta1(:,2:end);
 Theta2_grad(:,2:end)=Theta2_grad(:,2:end)+(lambda/m)*Theta2(:,2:end);



% Unroll gradients
grad = [Theta1_grad(:) ; Theta2_grad(:)];


end
