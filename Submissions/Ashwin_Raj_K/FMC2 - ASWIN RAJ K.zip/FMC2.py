import numpy as np
from sklearn.decomposition import PCA

my_data1 = np.genfromtxt('fashion-mnist_train.csv', delimiter=',')
X = my_data1[1:,1:]
y = my_data1[1:,0]
pca = PCA(n_components=0.95)

X_reduced = pca.fit_transform(X)
np.savetxt("reduced.txt",X_reduced)
np.savetxt("reducedtarget",y)

my_data2 = np.genfromtxt('Q2_Clothing_test.csv', delimiter=',')
pca = PCA(n_components=187)
X2 = my_data2[1:,:]
X_test_reduced = pca.fit_transform(X2)
np.savetxt("reducedTest.txt",X_test_reduced)
