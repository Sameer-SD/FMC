import numpy as np
from sklearn.neighbors import KNeighborsClassifier
X = np.loadtxt("reduced.txt")
y = np.loadtxt("reducedtarget.txt")
X2_test = np.loadtxt("reducedTest.txt")
clf = KNeighborsClassifier(n_neighbors=7)
clf.fit(X,y)
y_pred = clf.predict(X2_test)
np.savetxt("Q2Answer.txt",y_pred.reshape(-1,1))

